<?php
session_start();
if (!isset($_SESSION['nombre'])) {
    header('Location: registro.php');
    exit();
}
?>
<button type="button" onclick="window.location.href='index.html'">Ir a la Pagina Web</button>