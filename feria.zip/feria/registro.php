
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Registro de Estudiante</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <h1>Registro de Usuario</h1>
    <form action="registro.php" method="POST">
        <label for="nombre">Nombre:</label>
        <input type="text" id="nombre" name="nombre" required><br>
        <label for="apellido">Apellido:</label>
        <input type="text" id="apellido" name="apellido" required><br>
        <label for="facultad">Facultad:</label>
        <input type="text" id="facultad" name="facultad" required><br>
        <label for="lic">Licenciatura:</label>
        <input type="text" id="lic" name="lic" required><br>
        <button type="submit">Registrar</button>
        <button type="button" onclick="window.location.href='index.html'">Ir a la Pagina Web</button>
        <button onclick="window.location.href='index.html'">Modo Invitado</button>
    </form>
</body>
</html>
<?php
include 'conexion.php';
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nombre = $_POST['nombre'];
    $apellido = $_POST['apellido'];
    $facultad = $_POST['facultad'];
    $lic = $_POST['lic'];
    $sql = "INSERT INTO estudiante_latina (nombre, apellido, facultad, lic) VALUES ('$nombre', '$apellido', '$facultad', '$lic')";
    if ($conn->query($sql) === TRUE) {
        echo "Estudiante guardado exitosamente";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
    $conn->close();
}
?>
